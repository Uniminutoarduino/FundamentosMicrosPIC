/**
   EXT_INT Generated Driver File
 
   @Company
     Microchip Technology Inc.
 
   @File Name
     ext_int.c
 
   @Summary
     This is the generated driver implementation file for the EXT_INT driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs
 
   @Description
     This source file provides implementations for driver APIs for EXT_INT.
     Generation Information :
         Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
         Device            :  PIC18F25K50
         Driver Version    :  1.11
     The generated drivers are tested against the following:
         Compiler          :  XC8 2.36 and above
         MPLAB             :  MPLAB X 6.00
 */ 

 /**
   Section: Includes
 */
#include <xc.h>
#include "ext_int.h"
volatile char ciclo = 0;

void (*INT2_InterruptHandler)(void);

void INT2_ISR(void)
{
    EXT_INT2_InterruptFlagClear();

    // Callback function gets called everytime this ISR executes
    INT2_CallBack();    
}


void INT2_CallBack(void)
{
    // Add your custom callback code here
    if(INT2_InterruptHandler)
    {
         ciclo++;
        if (ciclo == 1){
            T0CONbits.TMR0ON = 1; //Activar temporizador cuando se detecta la interrupcion externa
             if (escalacolor == 1){//Almacenar contador escala rojo (R))
                S2 = 0; //La escala del sensor es rojo
                asm("nop");
                LEDS2 = 0;
                asm("nop");
                S3 = 0;
                asm("nop");
                LEDS3 = 0;
                asm("nop");
            }else if (escalacolor == 2){ //ContadorEscalaAzul
                S2 = 0; //La escala del sensor es azul
                asm("nop");
                LEDS2 = 0;
                asm("nop");
                S3 = 1;
                asm("nop");
                LEDS3 = 1;
                asm("nop");
            }else if (escalacolor == 3){ //ContadorEscalaVerde
                S2 = 1; //La escala del sensor es verde
                asm("nop");
                LEDS2 = 1;
                asm("nop");
                S3 = 1;
                asm("nop");
                LEDS3 = 1;
                asm("nop");
            }
                 
        }
        
        if (ciclo == 2){ // en el siguiente flanco detener el timer
            T0CONbits.TMR0ON = 0; //Detener timer
            if (escalacolor == 1){//Almacenar contador escala rojo (R))
                ContadorRojo = TMR0; //Leer valor del timer equivalente para escala en rojo
            }else if (escalacolor == 2){ //ContadorEscalaAzul
                ContadorAzul = TMR0;
            }else if (escalacolor == 3){ //ContadorEscalaVerde
                ContadorVerde = TMR0;
            }
            ciclo = 0;
            TMR0 = 0; //Reiniciar el conteo
        }

        
        INT2_InterruptHandler();
    }
}

void INT2_SetInterruptHandler(void (* InterruptHandler)(void)){
    INT2_InterruptHandler = InterruptHandler;
}

void INT2_DefaultInterruptHandler(void){
    // add your INT2 interrupt custom code
    // or set custom function using INT2_SetInterruptHandler()
}

void EXT_INT_Initialize(void)
{
    
    // Clear the interrupt flag
    // Set the external interrupt edge detect
    EXT_INT2_InterruptFlagClear();   
    EXT_INT2_risingEdgeSet();    
    // Set Default Interrupt Handler
    INT2_SetInterruptHandler(INT2_DefaultInterruptHandler);
    EXT_INT2_InterruptEnable();      

}

